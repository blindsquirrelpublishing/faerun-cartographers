# Fantasy Land Cover Map

Forest, grassland, cropland, marsh, scrub, rock and water.

Install as a reusable map-making skill using the enclosed `SKILL.md`. This is a new skill, not one of the seven previously created skills.

**Core rule:** Preserve user-provided map geometry and crop. Do not add any unsupported roads, paths, or landmarks.
